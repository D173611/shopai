"use client";
import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);
const SUPER_PASS = "admin123"; // CHANGE THIS NOW

const addDays = (dateStr:string | null, days:number) => {
  const d = dateStr? new Date(dateStr) : new Date(); // If null, start from today
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

export default function SuperAdmin() {
  const [pass, setPass] = useState(""); const [unlocked, setUnlocked] = useState(false);
  const [shops, setShops] = useState<any[]>([]); const [payments, setPayments] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({});

  useEffect(() => { if(unlocked){
    supabase.from('shops').select('*').order('created_at', { ascending: false }).then(({data})=>setShops(data||[]));
    supabase.from('payments').select('*, shops(name,slug)').eq('status','pending').order('created_at', {ascending:false}).then(({data})=>setPayments(data||[]));
    supabase.from('app_settings').select('*').single().then(({data})=>setSettings(data||{}));
  }}, [unlocked]);

  const extend = async (shopId:string, days:number) => {
    const shop = shops.find(s=>s.id===shopId);
    const newDate = addDays(shop.approved_until, days);
    await supabase.from('shops').update({is_active:true, approved_until:newDate}).eq('id',shopId);
    setShops(s => s.map(x => x.id===shopId? {...x, is_active:true, approved_until:newDate} : x));
    alert(`${shop.name} extended to ${newDate}`);
  }

  const approveTx = async (p:any) => {
    await extend(p.shop_id, 30); // Approve = +30 days
    await supabase.from('payments').update({status:'approved'}).eq('id',p.id);
    setPayments(payments.filter(x=>x.id!==p.id));
  }

  const rejectTx = async (id:string) => {
    await supabase.from('payments').update({status:'rejected'}).eq('id',id);
    setPayments(payments.filter(x=>x.id!==id));
  }

  const saveSettings = async () => {
    await supabase.from('app_settings').upsert({id:1,...settings});
    alert('Settings Saved ✅');
  }

  if (!unlocked) return <div className="min-h-screen flex items-center justify-center bg-gray-100"><div className="p-6 bg-white rounded-xl shadow w-80"><h1 className="font-bold text-xl mb-4">Super Admin Login</h1><input type="password" placeholder="Password" onChange={e=>setPass(e.target.value)} className="border p-2 w-full rounded mb-3"/><button onClick={()=>pass===SUPER_PASS?setUnlocked(true):alert("Wrong")} className="w-full bg-black text-white p-2 rounded">Login</button></div></div>;

  return <div className="p-4 space-y-6 max-w-5xl mx-auto bg-gray-50 min-h-screen">
    <h1 className="text-2xl font-bold">ShopHub Super Admin 🇺🇬</h1>

    <div className="bg-white p-4 rounded-xl shadow">
      <h2 className="font-bold text-lg mb-2">1. Your Help + Payment Details</h2>
      <p className="text-xs text-gray-500 mb-3">This is what customers see on signup page.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        <input placeholder="Help Email" value={settings.help_email||''} onChange={e=>setSettings({...settings,help_email:e.target.value})} className="border p-2 rounded"/>
        <input placeholder="Help Phone 07..." value={settings.help_phone||''} onChange={e=>setSettings({...settings,help_phone:e.target.value})} className="border p-2 rounded"/>
        <input placeholder="MTN MoMo 07..." value={settings.mtn_momo||''} onChange={e=>setSettings({...settings,mtn_momo:e.target.value})} className="border p-2 rounded"/>
        <input placeholder="Airtel Money 07..." value={settings.airtel_momo||''} onChange={e=>setSettings({...settings,airtel_momo:e.target.value})} className="border p-2 rounded"/>
        <input placeholder="Bank Name" value={settings.bank_name||''} onChange={e=>setSettings({...settings,bank_name:e.target.value})} className="border p-2 rounded"/>
        <input placeholder="Bank Acc Number" value={settings.bank_account_number||''} onChange={e=>setSettings({...settings,bank_account_number:e.target.value})} className="border p-2 rounded"/>
      </div>
      <button onClick={saveSettings} className="bg-black text-white p-2 rounded mt-3 w-full md:w-auto">Save All Details</button>
    </div>

    <div className="bg-white p-4 rounded-xl shadow">
      <h2 className="font-bold text-lg mb-2">2. Pending Payments: {payments.length}</h2>
      {payments.length===0? <p className="text-gray-500 text-sm">No pending TXIDs</p> :
      payments.map(p=><div key={p.id} className="border-b py-3 flex flex-col md:flex-row justify-between md:items-center gap-2">
        <div>
          <p className="font-bold">{p.shops.name} <span className="text-gray-500">/{p.shops.slug}</span></p>
          <p className="text-xs">{p.method} | TXID: <b>{p.txid}</b></p>
        </div>
        <div className="space-x-2">
          <button onClick={()=>rejectTx(p.id)} className="bg-red-500 text-white px-3 py-1 rounded text-sm">Reject</button>
          <button onClick={()=>approveTx(p)} className="bg-green-600 text-white px-3 py-1 rounded text-sm">Approve +30d</button>
        </div>
      </div>)}
    </div>

    <div className="bg-white p-4 rounded-xl shadow">
      <h2 className="font-bold text-lg mb-2">3. All Shops: Extend or Cut Off</h2>
      {shops.map(s=><div key={s.id} className="border-b py-3 flex-col md:flex-row justify-between md:items-center gap-2">
        <div>
          <p className="font-bold">{s.name} <span className={`text-xs font-bold ${s.is_active?'text-green-600':'text-red-600'}`}>{s.is_active?'Active':'Cut Off'}</span></p>
          <p className="text-xs">Due: {s.approved_until || 'Never paid'}</p>
        </div>
        <div className="space-x-1 flex-shrink-0">
          <button onClick={()=>extend(s.id, 7)} className="bg-gray-200 px-2 py-1 text-xs rounded">+7</button>
          <button onClick={()=>extend(s.id, 15)} className="bg-gray-200 px-2 py-1 text-xs rounded">+15</button>
          <button onClick={()=>extend(s.id, 30)} className="bg-green-600 text-white px-2 py-1 text-xs rounded">+30</button>
          <button onClick={()=>extend(s.id, 90)} className="bg-blue-600 text-white px-2 py-1 text-xs rounded">+90</button>
        </div>
      </div>)}
    </div>
  </div>
}