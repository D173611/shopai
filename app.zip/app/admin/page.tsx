"use client";
import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

export default function Admin() {
  const { slug } = useParams();
  const [shop, setShop] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    loadShop();
  }, [slug]);

  const loadShop = async () => {
    // TODO: Later check if user session matches shop.owner_phone
    const { data, error } = await supabase.from('shops').select('*').eq('slug', slug).single();
    if (error ||!data) return router.push('/login');
    setShop(data);
  };

  const toggle = async () => {
    await supabase.from('shops').update({ is_active:!shop.is_active }).eq('id', shop.id);
    setShop({...shop, is_active:!shop.is_active});
  }

  if (!shop) return <p className="p-10">Loading...</p>;

  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-2xl font-bold">{shop.name} Admin</h1>
      <p className="text-gray-500 mb-4">Link: {slug}.shophub.ug</p>
      
      <div className="bg-white p-4 rounded-xl shadow space-y-2">
        <p><b>Owner Phone:</b> {shop.owner_phone}</p>
        <p><b>Status:</b> {shop.is_active? '🟢 Active' : '🔴 Cut Off'}</p>
        
        <button onClick={toggle} className={`w-full p-3 rounded-lg font-bold text-white ${shop.is_active? 'bg-red-600' : 'bg-green-600'}`}>
          {shop.is_active? 'Cut Off Shop' : 'Reactivate Shop'}
        </button>
      </div>

      <Link href={`/${slug}/pos`} className="block text-center mt-4 underline">Go to POS</Link>
      <Link href={`/${slug}`} className="block text-center mt-2 underline">View Public Store</Link>
    </div>
  );
}