"use client";
import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { useParams, useRouter } from "next/navigation";

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

type Product = { id: number; name: string; price: number; stock: number; };
type Staff = { id: number; name: string; pin: string; };
type CartItem = Product & { qty: number };

export default function POS() {
  const { slug } = useParams();
  const [shop, setShop] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [staff, setStaff] = useState<Staff[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cashier, setCashier] = useState<Staff | null>(null);
  const [pin, setPin] = useState("");
  const [search, setSearch] = useState("");
  const router = useRouter();

  useEffect(() => {
    loadShop();
  }, );

  const loadShop = async () => {
    const { data: s } = await supabase.from('shops').select('*').eq('slug', slug).single();
    if (!s ||!s.is_active) return router.push('/login');
    setShop(s);
    const { data: p } = await supabase.from('products').select('id,name,price,stock').eq('shop_id', s.id).gt('stock', 0);
    setProducts(p || []);
    const { data: st } = await supabase.from('staff').select('id,name,pin').eq('shop_id', s.id);
    setStaff(st || []);
  };

  const loginCashier = () => {
    const found = staff.find(s => s.pin === pin);
    if (!found) return alert("Wrong PIN");
    setCashier(found);
    setPin("");
  };

  const addToCart = (p: Product) => {
    setCart(c => {
      const f = c.find(i => i.id === p.id);
      if (f) {
        if (f.qty >= p.stock) return c;
        return c.map(i => i.id === p.id? {...i, qty: i.qty + 1} : i);
      }
      return [...c, {...p, qty: 1}];
    });
  };

  const updateQty = (id: number, qty: number) => {
    if (qty < 1) return setCart(c => c.filter(i => i.id!== id));
    setCart(c => c.map(i => i.id === id? {...i, qty} : i));
  };

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const checkout = async () => {
    if (!cart.length ||!cashier ||!shop) return;
    const { data: order, error } = await supabase.from("orders").insert({
      shop_id: shop.id,
      cashier_id: cashier.id,
      items: cart.map(({id, name, price, qty}) => ({id, name, price, qty})),
      total,
      status: 'paid'
    }).select().single();
    
    if (error) return alert(error.message);
    
    // Update stock
    for (const item of cart) {
      await supabase.from("products").update({ stock: item.stock - item.qty }).eq("id", item.id);
    }
    
    alert(`Sale #${order.id} Complete! UGX ${total.toLocaleString()}`);
    setCart([]);
    loadShop(); // Refresh stock
  };

  if (!shop) return <p className="p-10 text-center">Loading...</p>;

  // PIN LOGIN SCREEN
  if (!cashier) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-900 p-4">
        <div className="bg-white p-6 rounded-2xl shadow-2xl w-full max-w-sm">
          <h1 className="text-2xl font-bold text-center mb-1">{shop.name}</h1>
          <p className="text-center text-gray-500 mb-6">Cashier Login</p>
          <input 
            type="password" 
            inputMode="numeric"
            maxLength={4}
            value={pin} 
            onChange={e=>setPin(e.target.value)} 
            onKeyDown={e=>e.key==='Enter'&&loginCashier()}
            className="w-full border-2 p-4 rounded-xl text-center text-2xl tracking-[1em] mb-3" 
            placeholder="••••" 
            autoFocus
          />
          <button onClick={loginCashier} className="w-full bg-black text-white p-3 rounded-xl font-bold">
            Login
          </button>
          <button onClick={() => router.push(`/admin/${slug}`)} className="w-full text-sm text-gray-500 mt-3">
            Back to Admin
          </button>
        </div>
      </div>
    );
  }

  // POS SCREEN
  const filtered = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* PRODUCTS */}
      <div className="flex-1 p-4">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-xl font-bold">{shop.name} POS</h1>
          <div className="text-sm">
            <span className="font-bold">{cashier.name}</span>
            <button onClick={() => setCashier(null)} className="ml-2 text-red-600 underline">Logout</button>
          </div>
        </div>
        <input 
          className="border p-3 w-full mb-3 rounded-lg text-base" 
          placeholder="Search product..." 
          value={search} 
          onChange={e=>setSearch(e.target.value)} 
        />
        <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
          {filtered.map(p => (
            <button 
              key={p.id} 
              onClick={() => addToCart(p)} 
              className="bg-white p-2 rounded-lg shadow border text-left active:scale-95 transition"
            >
              <p className="font-bold text-sm h-10">{p.name}</p>
              <p className="text-xs text-gray-600">Stock: {p.stock}</p>
              <p className="font-bold">UGX {p.price.toLocaleString()}</p>
            </button>
          ))}
        </div>
      </div>

      {/* CART */}
      <div className="w-80 bg-white border-l flex flex-col">
        <div className="p-4 border-b">
          <h2 className="font-bold text-lg">Current Sale</h2>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {cart.length === 0? <p className="text-center text-gray-500 mt-10">Tap products to add</p> : 
            cart.map(i => (
              <div key={i.id} className="flex items-center gap-2 border-b py-2">
                <div className="flex-1">
                  <p className="font-semibold text-sm">{i.name}</p>
                  <p className="text-xs">UGX {i.price.toLocaleString()}</p>
                </div>
                <input 
                  type="number" 
                  value={i.qty} 
                  onChange={e => updateQty(i.id, Number(e.target.value))} 
                  className="w-12 border p-1 text-center rounded" 
                />
              </div>
            ))
          }
        </div>
        {cart.length > 0 && (
          <div className="border-t p-4">
            <div className="flex justify-between font-bold text-xl mb-3">
              <span>Total:</span>
              <span>UGX {total.toLocaleString()}</span>
            </div>
            <button onClick={checkout} className="w-full bg-green-600 text-white p-4 rounded-xl font-bold text-lg active:scale-95">
              COMPLETE SALE
            </button>
          </div>
        )}
      </div>
    </div>
  );
}