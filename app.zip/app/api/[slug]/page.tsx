import { createClient } from '@/utils/supabase/server'
import { notFound } from 'next/navigation'
import Link from 'next/link'

export default async function StorePage({ params }: { params: { slug: string } }) {
  const supabase = await createClient() // <- added await here
  
  // Get shop
  const { data: shop, error: shopError } = await supabase
    .from('shops')
    .select('*')
    .eq('slug', params.slug)
    .eq('is_active', true)
    .single()
    
  if (shopError || !shop) notFound()
  
  // Get products
  const { data: products } = await supabase
    .from('products')
    .select('*')
    .eq('shop_id', shop.id)
    .order('created_at', { ascending: false })
  
  // Check if current user owns this shop
  const { data: { user } } = await supabase.auth.getUser()
  const isOwner = user?.id === shop.user_id
  
  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">{shop.name}</h1>
        {isOwner && (
          <Link 
            href="/dashboard" 
            className="bg-black text-white px-4 py-2 rounded"
          >
            Manage Shop
          </Link>
        )}
      </div>
      
      {products?.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          <p className="text-lg">No products yet</p>
          {isOwner && <p className="mt-2">Go to your dashboard to add products</p>}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products?.map(p => (
            <div key={p.id} className="border rounded-lg p-4 hover:shadow-md">
              <h3 className="font-semibold text-lg">{p.name}</h3>
              <p className="text-xl mt-2">${Number(p.price).toFixed(2)}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}