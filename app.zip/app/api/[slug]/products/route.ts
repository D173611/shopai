import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export const revalidate = 60 // Cache for 60 seconds

// GET /api/kato/products - Show products to customers
export async function GET(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const supabase = createClient()

  const { data: shop } = await supabase
    .from('shops')
    .select('id, name, is_active, whatsapp, location, slug')
    .eq('slug', params.slug)
    .single()

  if (!shop || !shop.is_active) {
    return NextResponse.json({ error: 'Shop not found or inactive' }, { status: 404 })
  }

  const { data: products } = await supabase
    .from('products')
    .select('id, name, price, stock, sku, category, image_url')
    .eq('shop_id', shop.id)
    .gt('stock', 0)
    .order('created_at', { ascending: false })

  return NextResponse.json({
    shop: {
      name: shop.name,
      whatsapp: shop.whatsapp,
      location: shop.location,
      storefront_url: `https://shophub.ug/${shop.slug}`
    },
    products: products || []
  })
}

// POST /api/kato/products - Customer places order
export async function POST(
  req: NextRequest,
  { params }: { params: { slug: string } }
) {
  const supabase = createClient()
  const body = await req.json()
  const { customer, items } = body

  // 1. Validate
  if (!items?.length) return NextResponse.json({ error: 'Cart is empty' }, { status: 400 })
  if (!customer?.location) return NextResponse.json({ error: 'Delivery location required' }, { status: 400 })
  if (!customer?.phone && !customer?.email && !customer?.telegram) {
    return NextResponse.json({ error: 'Provide WhatsApp, Email or Telegram' }, { status: 400 })
  }

  // 2. Get shop
  const { data: shop } = await supabase
    .from('shops')
    .select('id, is_active')
    .eq('slug', params.slug)
    .single()

  if (!shop || !shop.is_active) {
    return NextResponse.json({ error: 'Shop not found' }, { status: 404 })
  }

  // 3. Verify stock + calculate total
  let total_amount = 0
  const orderItems = []
  
  for (const item of items) {
    const { data: product } = await supabase
      .from('products')
      .select('id, name, price, stock')
      .eq('id', item.product_id)
      .eq('shop_id', shop.id)
      .single()

    if (!product || product.stock < item.quantity) {
      return NextResponse.json({ 
        error: `${product?.name || 'Product'} out of stock` 
      }, { status: 400 })
    }

    total_amount += product.price * item.quantity
    orderItems.push({
      product_id: product.id,
      product_name: product.name,
      quantity: item.quantity,
      price: product.price
    })
  }

  // 4. Create order
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert({
      shop_id: shop.id,
      customer_name: customer.name || null,
      customer_phone: customer.phone || null,
      customer_email: customer.email || null,
      customer_telegram: customer.telegram || null,
      customer_location: customer.location,
      total_amount
    })
    .select()
    .single()

  if (orderError) {
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }

  // 5. Create order items
  const itemsToInsert = orderItems.map(i => ({ ...i, order_id: order.id }))
  await supabase.from('order_items').insert(itemsToInsert)

  return NextResponse.json({
    success: true,
    order_id: order.id,
    total: total_amount,
    tracking_url: `https://shophub.ug/track/${order.id}`,
    message: 'Order placed successfully'
  })
}