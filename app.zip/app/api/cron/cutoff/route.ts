import { createClient } from "@supabase/supabase-js";
import { NextResponse } from "next/server";

const supabase = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_KEY!); // Use SERVICE KEY

export async function GET() {
  const today = new Date().toISOString().split('T')[0];
  const { data } = await supabase.from('shops').update({ is_active: false }).lt('approved_until', today).eq('is_active', true).select('name');
  return NextResponse.json({ cut_off: data?.length || 0 });
}