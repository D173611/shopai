import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(
  req: NextRequest,
  { params }: { params: { orderId: string } }
) {
  const supabase = createClient()

  const { data: order, error } = await supabase
    .from('orders')
    .select(`
      id,
      status,
      total_amount,
      customer_name,
      customer_location,
      created_at,
      shops (name, whatsapp),
      order_items (product_name, quantity, price)
    `)
    .eq('id', params.orderId)
    .single()

  if (error || !order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  }

  // Mask customer info for privacy
  const maskedOrder = {
    ...order,
    customer_name: order.customer_name ? order.customer_name.split(' ')[0] : 'Customer',
    customer_location: order.customer_location.split(',')[0] + ', ***'
  }

  return NextResponse.json({ order: maskedOrder })
}