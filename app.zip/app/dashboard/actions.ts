'use server'
import { createClient } from '@/utils/supabase/server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

export async function addProduct(formData: FormData) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) throw new Error('Not logged in')
  
  await supabase.from('products').insert({
    shop_id: formData.get('shop_id') as string,
    name: formData.get('name') as string,
    price: Number(formData.get('price'))
  })
  
  revalidatePath('/dashboard')
}

export async function deleteProduct(formData: FormData) {
  const supabase = createClient()
  const id = formData.get('id') as string
  await supabase.from('products').delete().eq('id', id)
  revalidatePath('/dashboard')
}

export async function logout() {
  const supabase = createClient()
  await supabase.auth.signOut()
  redirect('/login')
}