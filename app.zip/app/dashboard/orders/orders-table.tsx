'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter } from 'next/navigation'

type Order = {
  id: string
  customer_name: string | null
  customer_phone: string | null
  customer_email: string | null
  customer_telegram: string | null
  customer_location: string
  total_amount: number
  status: string
  created_at: string
  order_items: {
    product_name: string
    quantity: number
    price: number
  }[]
}

export default function OrdersTable({ orders }: { orders: Order[] }) {
  const [loadingId, setLoadingId] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  const updateStatus = async (orderId: string, newStatus: string) => {
    setLoadingId(orderId)
    const { error } = await supabase
     .from('orders')
     .update({ status: newStatus })
     .eq('id', orderId)

    if (error) {
      alert('Failed to update: ' + error.message)
    } else {
      router.refresh() // Reload the page data
    }
    setLoadingId(null)
  }

  const statusColor = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    delivered: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800'
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12 border rounded-lg">
        <p className="text-gray-500">No orders yet. Share your store link to start selling!</p>
      </div>
    )
  }

  return (
    <div className="border rounded-lg overflow-hidden">
      <table className="w-full">
        <thead className="bg-gray-50 border-b">
          <tr>
            <th className="text-left p-4">Order</th>
            <th className="text-left p-4">Customer</th>
            <th className="text-left p-4">Location</th>
            <th className="text-left p-4">Total</th>
            <th className="text-left p-4">Status</th>
            <th className="text-left p-4">Action</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id} className="border-b hover:bg-gray-50">
              <td className="p-4">
                <div className="font-medium">#{order.id.slice(0, 8)}</div>
                <div className="text-sm text-gray-500">
                  {new Date(order.created_at).toLocaleDateString()}
                </div>
                <details className="mt-2">
                  <summary className="text-xs text-blue-600 cursor-pointer">View items</summary>
                  <div className="text-xs mt-1">
                    {order.order_items.map((item, i) => (
                      <div key={i}>{item.product_name} x{item.quantity}</div>
                    ))}
                  </div>
                </details>
              </td>
              <td className="p-4">
                <div>{order.customer_name || 'Customer'}</div>
                <div className="text-sm text-gray-500">
                  {order.customer_phone && <div>📱 {order.customer_phone}</div>}
                  {order.customer_email && <div>📧 {order.customer_email}</div>}
                  {order.customer_telegram && <div>✈️ {order.customer_telegram}</div>}
                </div>
              </td>
              <td className="p-4 text-sm">{order.customer_location}</td>
              <td className="p-4 font-medium">UGX {order.total_amount.toLocaleString()}</td>
              <td className="p-4">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColor[order.status as keyof typeof statusColor] || 'bg-gray-100'}`}>
                  {order.status.toUpperCase()}
                </span>
              </td>
              <td className="p-4">
                <div className="flex gap-2">
                  {order.status === 'pending' && (
                    <>
                      <button
                        onClick={() => updateStatus(order.id, 'confirmed')}
                        disabled={loadingId === order.id}
                        className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 disabled:opacity-50"
                      >
                        Confirm
                      </button>
                      <button
                        onClick={() => updateStatus(order.id, 'cancelled')}
                        disabled={loadingId === order.id}
                        className="px-3 py-1 bg-red-600 text-white text-sm rounded hover:bg-red-700 disabled:opacity-50"
                      >
                        Cancel
                      </button>
                    </>
                  )}
                  {order.status === 'confirmed' && (
                    <button
                      onClick={() => updateStatus(order.id, 'delivered')}
                      disabled={loadingId === order.id}
                      className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700 disabled:opacity-50"
                    >
                      Mark Delivered
                    </button>
                  )}
                  {(order.status === 'delivered' || order.status === 'cancelled') && (
                    <span className="text-sm text-gray-400">Done</span>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}