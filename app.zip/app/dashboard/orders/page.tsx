import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import OrdersTable from './orders-table'

// Force dynamic so we always get fresh orders
export const dynamic = 'force-dynamic'

export default async function OrdersPage() {
  const supabase = createClient()

  // 1. Check if user is logged in
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  // 2. Get the shop that belongs to this user
  const { data: shop } = await supabase
   .from('shops')
   .select('id, name')
   .eq('id', user.id)
   .single()

  if (!shop) {
    return <div className="p-8">No shop found. Please create your shop first.</div>
  }

  // 3. Get all orders for this shop + customer info + items
  const { data: orders } = await supabase
   .from('orders')
   .select(`
      id,
      customer_name,
      customer_phone,
      customer_email,
      customer_telegram,
      customer_location,
      total_amount,
      status,
      created_at,
      order_items (
        product_name,
        quantity,
        price
      )
    `)
   .eq('shop_id', shop.id)
   .order('created_at', { ascending: false })

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{shop.name} - Orders</h1>
        <p className="text-gray-600">Manage your customer orders here</p>
      </div>

      <OrdersTable orders={orders || []} />
    </div>
  )
}