import { createClient } from '@/utils/supabase/server'
import { redirect } from 'next/navigation'
import { addProduct, deleteProduct, logout } from './actions'
import Link from 'next/link'

export default async function Dashboard() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')
  
  const { data: shop } = await supabase
    .from('shops')
    .select('*')
    .eq('user_id', user.id)
    .single()
    
  if (!shop) redirect('/signup')
  
  const { data: products } = await supabase
    .from('products')
    .select('*')
    .eq('shop_id', shop.id)
    .order('created_at', { ascending: false })
  
  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-gray-600">{shop.name}</p>
        </div>
        <div className="flex gap-3">
          <Link 
            href={`/${shop.slug}`} 
            target="_blank"
            className="border px-4 py-2 rounded"
          >
            View Store
          </Link>
          <form action={logout}>
            <button className="bg-gray-200 px-4 py-2 rounded">Logout</button>
          </form>
        </div>
      </div>
      
      <form action={addProduct} className="mb-8 border p-6 rounded-lg">
        <h2 className="font-bold text-xl mb-4">Add Product</h2>
        <input type="hidden" name="shop_id" value={shop.id} />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input 
            name="name" 
            placeholder="Product name" 
            className="border p-2 rounded" 
            required 
          />
          <input 
            name="price" 
            type="number" 
            step="0.01" 
            placeholder="Price" 
            className="border p-2 rounded" 
            required 
          />
          <button className="bg-black text-white px-4 py-2 rounded">Add Product</button>
        </div>
      </form>
      
      <h2 className="font-bold text-xl mb-4">Your Products</h2>
      {products?.length === 0 ? (
        <p className="text-gray-500">No products yet. Add one above.</p>
      ) : (
        <div className="space-y-3">
          {products?.map(p => (
            <div key={p.id} className="border p-4 rounded-lg flex justify-between items-center">
              <div>
                <p className="font-semibold">{p.name}</p>
                <p className="text-gray-600">${Number(p.price).toFixed(2)}</p>
              </div>
              <form action={deleteProduct}>
                <input type="hidden" name="id" value={p.id} />
                <button className="text-red-600 hover:underline">Delete</button>
              </form>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}