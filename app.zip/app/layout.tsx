import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import PremiumBackground from "@/components/PremiumBackground"; // <<<< 1. Import our engine

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "RetailPro POS | Luxury Retail System",
  description: "Premium Multi-Shop POS for Uganda",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex-col">
        <PremiumBackground> {/* <<<< 2. Wrap everything here */}
          {children}
        </PremiumBackground>
      </body>
    </html>
  );
}