import { login } from './actions'

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <form action={login} className="p-8 border rounded-lg w-full max-w-sm">
        <h1 className="text-2xl font-bold mb-6">Log In</h1>
        <input 
          name="email" 
          type="email" 
          placeholder="Email" 
          required 
          className="border p-2 w-full mb-3 rounded" 
        />
        <input 
          name="password" 
          type="password" 
          placeholder="Password" 
          required 
          className="border p-2 w-full mb-4 rounded" 
        />
        <button className="bg-black text-white p-2 w-full rounded">Log In</button>
        <p className="text-sm text-center mt-4">
          No account? <a href="/signup" className="underline">Sign up</a>
        </p>
      </form>
    </div>
  )
}