import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md text-center border">
        <h1 className="text-3xl font-bold mb-2 text-black">ShopHub UG</h1>
        <p className="text-gray-600 mb-8">Launch your online POS + shop in 2 minutes</p>
        
        <Link 
          href="/signup" 
          className="block bg-black text-white w-full p-4 rounded-xl font-bold mb-3 active:scale-95 transition"
        >
          Create New Shop
        </Link>
        
        <Link 
          href="/login" 
          className="block border-2 border-black text-black w-full p-4 rounded-xl font-bold active:scale-95 transition"
        >
          Login to Your Shop
        </Link>
        
        <p className="text-xs text-gray-500 mt-8">
          Free 7-day trial. No TXID needed.
        </p>
      </div>
    </div>
  );
}