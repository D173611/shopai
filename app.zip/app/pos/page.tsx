'use client';
import { useEffect, useRef, useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { createClient } from '@supabase/supabase-js';
import { useParams } from 'next/navigation';

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

type Product = { id: number; name: string; price: number; sku: string; stock: number };
type CartItem = Product & { qty: number };
type Shop = { id: string; name: string; is_active: boolean; approved_until: string | null };
type Staff = { id: number; name: string; pin: string; role: string }; // NEW

export default function POS() {
  const { slug } = useParams();
  const [shop, setShop] = useState<Shop | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [scanning, setScanning] = useState(false);
  const [phone, setPhone] = useState("");
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);
  const receiptRef = useRef<HTMLDivElement>(null);

  // NEW: PIN LOGIN STATE
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [loggedInCashier, setLoggedInCashier] = useState<Staff | null>(null);
  const [loginError, setLoginError] = useState("");

  useEffect(() => {
    const getShop = async () => {
      const { data } = await supabase.from('shops').select('*').eq('slug', slug).single();
      setShop(data || null);
    };
    getShop();
  }, [slug]);

  useEffect(() => {
    if (scanning &&!scannerRef.current) {
      scannerRef.current = new Html5QrcodeScanner('reader', { fps: 10, qrbox: 250 });
      scannerRef.current.render(onScanSuccess, () => {});
    }
    return () => { scannerRef.current?.clear().catch(() => {}); };
  }, [scanning]);

  // NEW: PIN CHECK FUNCTION
  const handlePinLogin = async () => {
    if (!shop ||!pinInput || pinInput.length!== 4) return setLoginError("Enter 4 digit PIN");
    setLoginError("");

    const { data, error } = await supabase
     .from('staff')
     .select('*')
     .eq('shop_id', shop.id)
     .eq('pin', pinInput)
     .single();

    if (error ||!data) {
      return setLoginError("Wrong PIN. Ask your manager.");
    }

    setLoggedInCashier(data);
    setIsLoggedIn(true);
    setPinInput("");
  };

  const onScanSuccess = async (decodedText: string) => {
    setScanning(false);
    if (!shop?.id) return alert('Shop not loaded yet');
    const { data } = await supabase.from('products').select('*').eq('sku', decodedText).eq('shop_id', shop.id).single();
    if (data) addToCart(data);
    else alert('Product not found: ' + decodedText);
  };

  const addToCart = (p: Product) => {
    setCart(prev => {
      const found = prev.find(i => i.id === p.id);
      if (found) return prev.map(i => i.id === p.id? {...i, qty: i.qty + 1 } : i);
      return [...prev, {...p, qty: 1 }];
    });
  };

  const total = cart.reduce((sum, i) => sum + i.price * i.qty, 0);

  const checkout = async () => {
    if (!shop) return;
    if (!shop.is_active || (shop.approved_until && new Date(shop.approved_until) < new Date())) {
      return alert("Shop is INACTIVE. Pay your owner to reactivate.");
    }
    if (cart.length === 0) return alert("Cart is empty");

    // NEW: Save cashier_id with order
    const { data: order, error } = await supabase.from("orders").insert([{
      shop_id: shop.id,
      cashier_id: loggedInCashier?.id, // NEW
      items: cart,
      total,
      status: 'paid',
      customer_phone: phone || null
    }]).select().single();
    if (error) return alert(error.message);

    // Reduce stock
    for (const item of cart) {
      await supabase.from("products").update({ stock: item.stock - item.qty }).eq("id", item.id);
    }

    printReceipt(order.id);
    setCart([]);
    setPhone("");
    window.location.reload();
  };

  const printReceipt = (orderId: number) => {
    const receiptHTML = receiptRef.current?.innerHTML;
    const w = window.open('', '', 'height=600,width=400');
    w?.document.write('<html><head><title>Receipt</title><style>body{font-family:monospace;width:300px}</style></head><body>');
    w?.document.write(receiptHTML || "");
    w?.document.write('</body></html>');
    w?.document.close();
    w?.print();
  };

  const logout = () => { // NEW
    setIsLoggedIn(false);
    setLoggedInCashier(null);
    setCart([]);
  }

  if (!shop) return <p className="p-10 text-center">Loading Shop...</p>;

  // NEW: PIN GATE SCREEN
  if (!isLoggedIn) {
    return (
      <main className="p-4 max-w-sm mx-auto bg-gray-50 min-h-screen flex flex-col justify-center">
        <h1 className="text-3xl font-bold mb-2 text-center">{shop.name}</h1>
        <p className="text-center text-gray-600 mb-6">Cashier Login</p>
        <div className="bg-white p-6 rounded-xl shadow">
          <input
            type="password"
            inputMode="numeric"
            maxLength={4}
            placeholder="Enter 4 Digit PIN"
            value={pinInput}
            onChange={e => setPinInput(e.target.value)}
            className="w-full border p-4 rounded-lg text-center text-2xl tracking-[1em] mb-2"
          />
          {loginError && <p className="text-red-600 text-sm mb-2 text-center">{loginError}</p>}
          <button onClick={handlePinLogin} className="w-full bg-black text-white p-3 rounded-xl font-bold">Login</button>
        </div>
      </main>
    )
  }

  return (
    <main className="p-4 max-w-md mx-auto bg-gray-50 min-h-screen">
      <div className="flex justify-between items-center mb-1">
        <h1 className="text-2xl font-bold">{shop.name} POS</h1>
        <button onClick={logout} className="text-sm text-red-600 font-bold">Logout</button>
      </div>
      <p className="text-sm mb-1">Logged in as: <span className="font-bold">{loggedInCashier?.name}</span></p> {/* NEW */}
      <div className={`text-xs font-bold mb-3 ${shop.is_active? "text-green-600" : "text-red-600"}`}>
        {shop.is_active? `Active till ${shop.approved_until}` : "INACTIVE"}
      </div>

      <button onClick={() => setScanning(true)} className="w-full bg-black text-white p-3 rounded-xl mb-4">
        📷 Scan QR Code
      </button>
      {scanning && <div id="reader" className="mb-4 border rounded-lg"></div>}

      <div className="bg-white p-4 rounded-xl shadow space-y-3">
        <h2 className="font-bold">Cart</h2>
        {cart.length === 0? <p className="text-gray-500 text-sm">Scan a product to add</p> :
          cart.map(i => <div key={i.id} className="flex justify-between py-1 text-sm">
            <span>{i.name} x{i.qty}</span>
            <span>UGX {(i.price * i.qty).toLocaleString()}</span>
          </div>)
        }
        <div className="border-t pt-2 font-bold text-xl flex justify-between">
          <span>Total:</span> <span>UGX {total.toLocaleString()}</span>
        </div>
        <input placeholder="Customer Phone 07..." value={phone} onChange={e => setPhone(e.target.value)} className="w-full border p-2 rounded text-sm" />
        <button onClick={checkout} className="w-full bg-green-600 text-white p-3 rounded-xl font-bold">Checkout & Print</button>
      </div>

      {/* Hidden Receipt */}
      <div style={{display: 'none'}}>
        <div ref={receiptRef}>
          <h2 style={{textAlign: 'center'}}>{shop.name}</h2>
          <p>Cashier: {loggedInCashier?.name}</p> {/* NEW */}
          <p>Order #{Date.now().toString().slice(-6)}</p><hr />
          {cart.map(i => <p key={i.id}>{i.name} x{i.qty} = {i.price * i.qty}</p>)}
          <hr /><h3>Total: UGX {total.toLocaleString()}</h3>
          <p style={{textAlign: 'center', fontSize: '12px'}}>Thank you!</p>
        </div>
      </div>
    </main>
  );
}