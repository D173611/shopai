'use server'
import { createClient } from '@/utils/supabase/server'
import { redirect } from 'next/navigation'

export async function signup(formData: FormData) {
  const supabase = await createClient() // <- await is important
  
  const email = formData.get('email') as string
  const password = formData.get('password') as string
  const shopName = formData.get('shopName') as string
  const slug = formData.get('slug') as string
  
  // 1. Create auth user
  const { data: authData, error: authError } = await supabase.auth.signUp({ 
    email, 
    password 
  })
  if (authError || !authData.user) {
    redirect('/signup?error=Could not create user')
  }
  
  // 2. Create shop for that user
  const { error: shopError } = await supabase.from('shops').insert({
    user_id: authData.user.id,
    name: shopName,
    slug: slug
  })
  if (shopError) {
    redirect('/signup?error=Shop slug already taken')
  }
  
  redirect('/dashboard')
}