import { signup } from './actions'

export default function SignupPage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <form action={signup} className="p-8 border rounded-lg w-full max-w-sm">
        <h1 className="text-2xl font-bold mb-6">Create Your Shop</h1>
        <input 
          name="email" 
          type="email" 
          placeholder="Email" 
          required 
          className="border p-2 w-full mb-3 rounded" 
        />
        <input 
          name="password" 
          type="password" 
          placeholder="Password" 
          required 
          className="border p-2 w-full mb-3 rounded" 
        />
        <input 
          name="shopName" 
          placeholder="Shop Name" 
          required 
          className="border p-2 w-full mb-3 rounded" 
        />
        <input 
          name="slug" 
          placeholder="shop-url-slug" 
          required 
          className="border p-2 w-full mb-4 rounded" 
        />
        <button className="bg-black text-white p-2 w-full rounded">Sign Up</button>
        <p className="text-sm text-center mt-4">
          Have an account? <a href="/login" className="underline">Log in</a>
        </p>
      </form>
    </div>
  )
}