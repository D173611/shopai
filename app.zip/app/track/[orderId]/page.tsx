'use client'
import { useEffect, useState } from 'react'

export default function TrackOrder({ params }: { params: { orderId: string } }) {
  const [order, setOrder] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`/api/orders/${params.orderId}`)
      .then(res => res.json())
      .then(data => {
        setOrder(data.order)
        setLoading(false)
      })
  }, [params.orderId])

  if (loading) return <div style={{padding:40, textAlign:'center'}}>Loading order...</div>
  if (!order) return <div style={{padding:40, textAlign:'center'}}>Order not found</div>

  const statusColor = {
    pending: '#f59e0b',
    confirmed: '#3b82f6',
    delivered: '#10b981',
    cancelled: '#ef4444'
  }[order.status] || '#6b7280'

  return (
    <div style={{maxWidth:600, margin:'40px auto', padding:20, fontFamily:'system-ui'}}>
      <h1>Track Your Order</h1>
      <div style={{border:'1px solid #ddd', padding:20, borderRadius:8}}>
        <p><b>Shop:</b> {order.shops.name}</p>
        <p><b>Order ID:</b> {order.id.slice(0,8)}...</p>
        <p><b>Status:</b> <span style={{color:statusColor, fontWeight:'bold'}}>{order.status.toUpperCase()}</span></p>
        <p><b>Total:</b> UGX {order.total_amount.toLocaleString()}</p>
        <p><b>Deliver to:</b> {order.customer_location}</p>
        <hr style={{margin:'16px 0'}} />
        <h3>Items Ordered:</h3>
        {order.order_items.map((item:any, i:number) => (
          <div key={i} style={{display:'flex', justifyContent:'space-between', margin:'8px 0'}}>
            <span>{item.product_name} x{item.quantity}</span>
            <span>UGX {(item.price * item.quantity).toLocaleString()}</span>
          </div>
        ))}
        <hr style={{margin:'16px 0'}} />
        <a href={`https://wa.me/${order.shops.whatsapp?.replace('+','')}`}
           style={{display:'block', padding:12, background:'#25D366', color:'white', textAlign:'center', textDecoration:'none', borderRadius:4}}>
          Contact Shop on WhatsApp
        </a>
      </div>
    </div>
  )
}